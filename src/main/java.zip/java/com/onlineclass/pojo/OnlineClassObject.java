package com.onlineclass.pojo;

import java.io.Serializable;

/**
 * 
 * @author indext
 * @since 2019.10.10
 * @version 1.0
 *
 */
public class OnlineClassObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
